# website-contentful-data-transfer

Standalone script that fetched up-to-date info from associated services (Meetup, YouTube) and creates new Contentful entries as necessary
